###################
# Lab 1 Solution  #
###################

# Create New Project
echo "TODO: run 'oc new-project PROJECT_NAME'"

# Download Projects
curl -sL -o projects.zip https://github.com/openshift-labs/cloud-native-labs/archive/ocp-3.10.zip

echo "TODO: unzip projects.zip"